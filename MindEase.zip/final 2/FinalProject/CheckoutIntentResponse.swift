//
//  CheckoutIntentResponse.swift
//  FinalProject
//
//  Created by Meghana Pathapati on 4/27/24.
//

import Foundation

struct CheckoutIntentResponse: Decodable {
    let clientSecret: String
}
